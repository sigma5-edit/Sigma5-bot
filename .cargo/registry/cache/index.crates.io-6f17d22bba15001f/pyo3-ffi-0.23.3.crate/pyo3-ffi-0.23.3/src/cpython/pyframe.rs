#[cfg(Py_3_11)]
opaque_struct!(_PyInterpreterFrame);
