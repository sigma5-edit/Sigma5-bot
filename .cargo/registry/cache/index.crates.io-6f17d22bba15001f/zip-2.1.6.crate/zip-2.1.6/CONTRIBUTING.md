Pull requests are welcome, but they're subject to some requirements that a lot of them don't meet. See https://github.com/zip-rs/zip2/raw/master/pull_request_template.md for details.
